from typing import Dict, Any
from llama_index.core import Document
import pandas as pd
from rouge_score import rouge_scorer
from .vat_rag import VatRag


class GLPredictor:
    """GL Code Prediction Agent for VAT and Chart of Account predictions"""

    def __init__(self, vat_rag: VatRag):
        """Initialize the GL Predictor with a VatRag instance"""
        self.vat_rag = vat_rag
        self.scorer = rouge_scorer.RougeScorer(['rouge1'], use_stemmer=True)

    def predict(self, invoice_text: str) -> Dict[str, Any]:
        """
        Predict VAT % and Chart of Account category for an invoice

        Args:
            invoice_text: The text content of the invoice

        Returns:
            Dictionary containing predictions and supporting information
        """
        # Query VAT legislation for relevant information
        vat_query = f"What VAT rate applies to the following invoice: {invoice_text}"
        vat_response = self.vat_rag.query(vat_query)

        # Query for account categorization
        category_query = f"Which chart of account category best fits this invoice: {invoice_text}"
        category_response = self.vat_rag.query(category_query)

        # Extract predictions using the responses
        vat_prediction = self._extract_vat_rate(vat_response['response'])
        category_prediction = self._extract_category(category_response['response'])

        # Calculate ROUGE scores
        vat_rouge = self.scorer.score(invoice_text, vat_response['response'])
        category_rouge = self.scorer.score(invoice_text, category_response['response'])

        return {
            "vat_prediction": {
                "rate": vat_prediction,
                "rouge_score": vat_rouge['rouge1'].fmeasure,
                "reference": vat_response['source_nodes']
            },
            "category_prediction": {
                "category": category_prediction,
                "rouge_score": category_rouge['rouge1'].fmeasure,
                "reference": category_response['source_nodes']
            }
        }

    def _extract_vat_rate(self, response: str) -> float:
        """Extract VAT rate from response text"""
        # Simple extraction logic - can be enhanced
        if "20%" in response or "standard rate" in response.lower():
            return 20.0
        elif "5%" in response or "reduced rate" in response.lower():
            return 5.0
        elif "0%" in response or "zero rate" in response.lower():
            return 0.0
        return None

    def _extract_category(self, response: str) -> str:
        """Extract chart of account category from response text"""
        # Simple category mapping - can be enhanced
        categories = {
            "goods": "Purchases",
            "service": "Professional Services",
            "utility": "Utilities",
            "rent": "Rent and Rates",
            "travel": "Travel Expenses"
        }

        response_lower = response.lower()
        for key, category in categories.items():
            if key in response_lower:
                return category
        return "Other Expenses"