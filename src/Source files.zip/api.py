from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any
import mlflow
from .gl_predictor import GLPredictor
from .vat_rag import VatRag


class InvoiceRequest(BaseModel):
    data: str


class PredictionResponse(BaseModel):
    vat_prediction: Dict[str, Any]
    category_prediction: Dict[str, Any]


app = FastAPI()

# Initialize VAT RAG and GL Predictor
vat_rag = VatRag("data/vat_legislation.csv")
vat_rag.load_documents()
vat_rag.build_index()
predictor = GLPredictor(vat_rag)


@app.post("/predict", response_model=PredictionResponse)
async def predict_gl_codes(request: InvoiceRequest):
    """Endpoint to predict VAT rate and Chart of Account category"""
    try:
        # Get predictions
        predictions = predictor.predict(request.data)

        # Log to MLFlow
        with mlflow.start_run():
            mlflow.log_metrics({
                "vat_rouge_score": predictions["vat_prediction"]["rouge_score"],
                "category_rouge_score": predictions["category_prediction"]["rouge_score"]
            })

        return predictions
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/evaluate")
async def evaluate_predictions(data: Dict[str, Dict[str, str]]):
    """Endpoint to evaluate predictions against actual values"""
    try:
        with mlflow.start_run():
            # Calculate accuracy metrics
            vat_match = data["VAT %"]["original"] == data["VAT %"]["prediction"]
            category_match = data["Chart of Account"]["original"] == data["Chart of Account"]["prediction"]

            # Log metrics
            mlflow.log_metrics({
                "vat_accuracy": int(vat_match),
                "category_accuracy": int(category_match),
                "overall_accuracy": (int(vat_match) + int(category_match)) / 2
            })

            return {
                "status": "Success",
                "metrics": {
                    "vat_accuracy": int(vat_match),
                    "category_accuracy": int(category_match)
                }
            }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))