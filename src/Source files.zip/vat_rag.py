from pathlib import Path
from llama_index.core import Document, VectorStoreIndex
from llama_index.llms.openai import OpenAI
from llama_index.core import Settings
import pandas as pd
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class VatRag:
    """VAT Retrieval Augmented Generation (RAG) System"""

    def __init__(
            self,
            csv_path: str,
            content_column: str = "page_content",
            id_column: str = "id",
            index_dir: str = "index"
    ):
        """Initialize VAT RAG system"""
        # Convert paths to Path objects
        self.csv_path = Path(csv_path)
        self.index_dir = Path(index_dir)

        # Create index directory if needed
        self.index_dir.mkdir(parents=True, exist_ok=True)

        try:
            # Load CSV data
            self.df = pd.read_csv(self.csv_path)
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise ValueError("OPENAI_API_KEY not found in environment variables")

            # Initialize OpenAI language model
            self.llm = OpenAI(api_key=api_key, model="gpt-4")

            # Set column names
            self.content_column = content_column
            self.id_column = id_column

            # Initialize empty containers
            self.documents = []
            self.index = None
            self.query_engine = None

        except Exception as e:
            print(f"Initialization error: {str(e)}")
            raise

    def load_documents(self):
        """Load documents from CSV file"""
        try:
            self.documents = [
                Document(
                    text=str(row[self.content_column]),
                    metadata={"id": row[self.id_column]}
                )
                for _, row in self.df.iterrows()
            ]
            return self.documents
        except Exception as e:
            print(f"Error loading documents: {str(e)}")
            raise

    def build_index(self):
        """Build vector store index"""
        try:
            if not self.documents:
                self.load_documents()

            Settings.llm = self.llm
            self.index = VectorStoreIndex.from_documents(
                self.documents
            )

            # Initialize query engine
            print(f"Index built successfully. Initializing query engine...")
            self.query_engine = self.index.as_query_engine()
            return self.index
        except Exception as e:
            print(f"Error building index: {str(e)}")
            raise

    def query(self, query: str) -> dict:
        """Query the index"""
        try:
            if not self.query_engine:
                raise ValueError("Index not built. Call build_index() first.")

            response = self.query_engine.query(query)
            return {
                "response": str(response),
                "source_nodes": [
                    {
                        "text": node.node.text,
                        "score": node.score,
                        "id": node.node.metadata.get("id")
                    }
                    for node in response.source_nodes
                ]
            }
        except Exception as e:
            print(f"Error querying index: {str(e)}")
            raise


def test_rag():
    """Test the RAG system"""
    try:
        print("Starting RAG system test...")

        # Get current file's directory and construct relative path to data
        current_dir = Path(__file__).parent.parent
        data_path = current_dir / "data" / "vat_legislation.csv"

        # Initialize RAG system
        vat_rag = VatRag(str(data_path))
        print("RAG system initialized")

        # Load documents
        print("Loading documents...")
        vat_rag.load_documents()
        print("Documents loaded successfully")

        # Build index
        print("Building index...")
        vat_rag.build_index()
        print("Index built successfully")

        # Test queries
        test_queries = [
            "What is the standard VAT rate in the UK?",
            "When do I need to register for VAT?",
            "What are the different VAT rates available?"
        ]

        print("\nTesting queries:")
        for query in test_queries:
            print(f"\nQuery: {query}")
            result = vat_rag.query(query)
            print(f"Response: {result['response']}")
            print(f"Number of sources: {len(result['source_nodes'])}")
            print(f"Source ids: {[node['id'] for node in result['source_nodes']]}")

        return True

    except Exception as e:
        print(f"\nTest failed with error: {str(e)}")
        return False


if __name__ == "__main__":
    test_rag()